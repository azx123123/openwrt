<template>
  <Header />
  <div class="mx-6">
    <slot />
  </div>
</template>
