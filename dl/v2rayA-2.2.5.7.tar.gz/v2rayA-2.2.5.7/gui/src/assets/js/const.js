export default {
  SubscriptionType: "subscription",
  ServerType: "server",
  SubscriptionServerType: "subscriptionServer",
};
