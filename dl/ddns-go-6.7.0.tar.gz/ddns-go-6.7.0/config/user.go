package config

// User 登录用户
type User struct {
	Username string
	Password string
}
