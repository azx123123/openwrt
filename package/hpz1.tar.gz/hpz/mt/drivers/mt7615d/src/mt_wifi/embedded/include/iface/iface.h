
#ifndef __IFACE_H__
#define __IFACE_H__

#ifdef MT_MAC
#if defined(RTMP_MAC_PCI) || defined(RTMP_MAC_USB)
#include "mt_hif_pci_usb.h"
#endif

#endif

#endif /* __IFACE_H__ */

